
export default function Home() {
  return (
    <div>
      <h1>Welcome to NelsonBot Drug Calculator</h1>
      <p>Deployable on Vercel!</p>
    </div>
  );
}
